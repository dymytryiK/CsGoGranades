const body = document.querySelector("body");

const popupLinks = document.querySelectorAll(".popup-link");
/*призначення функції відкривання popup*/
for (let index = 0; index < popupLinks.length; index++) {
  const popupLink = popupLinks[index];
  popupLink.addEventListener("click", function (e) {
    const popupName = popupLink.getAttribute("href").replace("#", "");
    let curPopup = document.getElementById(popupName);
    console.log(popupName);
    curPopup = fillContent(curPopup, popupLink.id);
    popupOpen(curPopup);
    e.preventDefault();
  });
}




function popupOpen(curentPopup) {
  if (curentPopup) {
    curentPopup.classList.add("open");
    curentPopup.addEventListener("click", function (e) {
      if (!e.target.closest(".popup_content")) {
        popupClose(e.target.closest(".popup"));
      }
    });
  }
}

/*призначення функції закривання popup з класом*/
const popupCloseIcon = document.querySelectorAll(".close-popup");
for (let index = 0; index < popupCloseIcon.length; index++) {
  const el = popupCloseIcon[index];
  el.addEventListener("click", function (e) {
    popupClose(el.closest(".popup"));
    e.preventDefault();
  });
}

function popupClose(popupActive) {
  const elements = document.querySelectorAll(".card-block > a");
  elements.forEach((el) => {
    el.remove();
  });
  popupActive.classList.remove("open");
}

