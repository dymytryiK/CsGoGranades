function fillContent(divPopup, id) {
  const content = divPopup.querySelector(".card-block");
  let number = parseInt(id.slice(id.indexOf("-") + 1));
  let newElement = document.createElement("a");

 console.log("ID =" + id);
  switch (id[0]) {
    case "s":
      switch (number) {
        case 1:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s1.png" alt="">
              <div class="card-text">
                <h3>Long Entrance Smoke</h3>
                <p>from Car</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=6uRWaLQW3Bc&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=1&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 2:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s2.png" alt="">
  
              <div class="card-text">
                <h3>Long Doors Smoke</h3>
                <p>from Mid Doors</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=rmdCYpMQVeg&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=2&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 3:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s3.png" alt="">
  
              <div class="card-text">
                <h3>Long Doors Smoke</h3>
                <p>from Car</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=v4vJgBzraYo&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=3&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 4:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s4.png" alt="">
  
              <div class="card-text">
                <h3>Blue Smoke</h3>
                <p>from A Dumpster</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=-jIzCREmsAA&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=4&ab_channel=BeaverUA "
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 5:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s5.png" alt="">
  
              <div class="card-text">
                <h3>Long Pit Corner Smoke</h3>
                <p>from Corner in front of</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=k2Dco7FBQy4&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=5&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 6:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s6.png" alt="">
  
              <div class="card-text">
                <h3>Long Smoke</h3>
                <p>from Outside Long</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=t4Cw8G-k4Ww&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=6&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 7:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s7.png" alt="">
  
              <div class="card-text">
                <h3>Long Corner Smoke</h3>
                <p>from Outside Long</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=o_9l-vRxp9A&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=7&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 8:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s8.png" alt="">
  
              <div class="card-text">
                <h3>Car Smoke</h3>
                <p>from Outside Long</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=dHwasvuE2zg&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=8&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;

        case 9:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s9.png" alt="">
  
              <div class="card-text">
                <h3>A Cross Smoke</h3>
                <p>from Long Doors</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=S0ui0vpmQXs&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=9&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;

        case 10:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s10.png" alt="">
  
              <div class="card-text">
                <h3>A Ramp Box Smoke</h3>
                <p>from Pit Plat</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=z52VxjSiXIQ&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=10&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 11:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s11.png" alt="">
  
              <div class="card-text">
                <h3>A Site Smoke</h3>
                <p>from Pit Plat</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=t3IQRvBO6Qc&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=11&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;

        case 12:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s12.png" alt="">
  
              <div class="card-text">
                <h3>Goose Smoke</h3>
                <p>from A Short</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=LfVJ9jRQxe8&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=12&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 13:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s13.png" alt="">
  
              <div class="card-text">
                <h3>Extended A One-Way Smoke</h3>
                <p>from Extended A</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=famfrtLMOK4&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=13&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 14:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s14.png" alt="">
  
              <div class="card-text">
                <h3>Under A One-Way Smoke</h3>
                <p>from Long A</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=-xOs7-QYW4s&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=14&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 15:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s15.png" alt="">
  
              <div class="card-text">
                <h3>CT Spawn Smoke</h3>
                <p>from Long Doors
  
                </p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=Y4t3xvAufHc&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=15&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;

        case 16:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s16.png" alt="">
  
              <div class="card-text">
                <h3>Dumpster Smoke</h3>
                <p>from A Short</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=2VT9v6bOitY&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=16&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 17:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s17.png" alt="">
  
              <div class="card-text">
                <h3>Short One-Way Smoke</h3>
                <p>from Short</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=gHQcQhTtng8&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=17&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 18:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s18.png" alt="">
  
              <div class="card-text">
                <h3>Short Smoke</h3>
                <p>from Goose</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=6kfVMtoPHFg&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=18&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 19:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s19.png" alt="">
  
              <div class="card-text">
                <h3>Short One-Way Smoke</h3>
                <p>from A Site</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=1WxKQNTAATY&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=19&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 20:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s20.png" alt="">
  
              <div class="card-text">
                <h3>Lower Mid Smoke</h3>
                <p>from CT Mid</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=-X-vQpV6dN4&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=20&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 21:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s21.png" alt="">
  
              <div class="card-text">
                <h3>XBox Smoke</h3>
                <p>from Top Mid</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=-J1N64OVr50&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=21&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 22:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s22.png" alt="">
  
              <div class="card-text">
                <h3>Mid Doors Smoke</h3>
                <p>from Mid Doors</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=HybikLbcUag&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=22&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 23:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s23.png" alt="">
  
              <div class="card-text">
                <h3>CT Spawn Smoke</h3>
                <p>from XBox</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=T41sdvG35Kc&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=23&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 24:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s24.png" alt="">
  
              <div class="card-text">
                <h3>CT Spawn Box Smoke</h3>
                <p>from XBox</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=VRaL8k7_OmA&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=24&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 25:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s25.png" alt="">
  
              <div class="card-text">
                <h3>CT Mid Smoke</h3>
                <p>from Lower Tunnel</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=otuwAUtJCKw&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=25&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 26:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s26.png" alt="">
  
              <div class="card-text">
                <h3>B Window Smoke</h3>
                <p>from Tunnel</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=OWurASB8JRY&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=26&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 27:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s27.png" alt="">
  
              <div class="card-text">
                <h3>B Doors Retake Smoke</h3>
                <p>from B Doors</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=YpQw9uy0PfI&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=27&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 28:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s28.png" alt="">
  
              <div class="card-text">
                <h3>B Door Smoke</h3>
                <p>from Upper Tunnel</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=ak3J2wTDnHU&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=28&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 29:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s29.png" alt="">
  
              <div class="card-text">
                <h3>B Site Car Smoke</h3>
                <p>from Outside B Doors</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=cWUQsvq4e08&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=29&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 30:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s30.png" alt="">
  
              <div class="card-text">
                <h3>Double Smoke</h3>
                <p>from Van</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=VXop1npTd0U&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=30&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 31:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s31.png" alt="">
  
              <div class="card-text">
                <h3>Back Plat Smoke</h3>
                <p>from Tunnels</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=92sriWZMwX0&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=31&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 32:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s32.png" alt="">
  
              <div class="card-text">
                <h3>B Plat Smoke</h3>
                <p>from Tunnels</p>
                <a target="_blank"
                href=""
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 33:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s33.png" alt="">
  
              <div class="card-text">
                <h3>Tunnel Entry One-Way Smoke</h3>
                <p>from Tunnels</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=Oz44NgIzHx8&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=32&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 34:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s34.png" alt="">
  
              <div class="card-text">
                <h3>Tunnels Smoke</h3>
                <p>from CT Mid</p>
                <a target="_blank"
                href=""
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 35:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust Sm/s35.png" alt="">
  
              <div class="card-text">
                <h3>Deep Tunnels Smoke</h3>
                <p>from B Plat</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=vjcb8JGYe80&list=PLWdS7h_tsqN4mW7R-CY_hdjjaQNK_Fw2Q&index=33&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
      }
      break;
    case "m":
      switch (number) {
        case 1:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/res/grenades/molotovs/m_1-2.jpg" alt="">
  
              <div class="card-text">
                <h3>Catwalk Molotov</h3>
                <p>Молотов на шорт</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=l2owrLeCB5w&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=2&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 2:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Dust 2/Dust molot/m2.png" alt="">
  
              <div class="card-text">
                <h3>Catwalk Molotov</h3>
                <p>Молотов 2</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=y7R00p9I9WU&ab_channel=WebUpBlog-%D0%A3%D1%80%D0%BE%D0%BA%D0%B8%D0%B2%D0%B5%D0%B1%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B8"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 3:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m3.png" alt="">
    
                <div class="card-text">
                  <h3>Short Molotov</h3>
                  <p>from Long Doors</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=vDBnqtvgy4k&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=3&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 4:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m4.png" alt="">
    
                <div class="card-text">
                  <h3>Short Molotov</h3>
                  <p>from Goose</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=GxIAQaYxnso&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=4&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 5:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m5.png" alt="">
              
    
                <div class="card-text">
                  <h3>Dumpster Molotov</h3>
                  <p>from Short</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=kM9M-Hkj56E&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=5&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 6:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m6.png" alt="">
    
                <div class="card-text">
                  <h3>Elevator Molotov</h3>
                  <p>from Long A</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=rE-DIFwx1eU&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=6&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 7:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m7.png" alt="">
    
                <div class="card-text">
                  <h3>A Site Molotov</h3>
                  <p>from CT Spawn</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=Uzr44v_C5ek&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=16&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;

        case 8:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m8.png" alt="">
    
                <div class="card-text">
                  <h3>Goose Molotov</h3>
                  <p>from Short</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=XMXG-I_ocpk&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=7&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 9:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m9.png" alt="">
    
                <div class="card-text">
                  <h3>Car Molotov</h3>
                  <p>from Long Doors</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=dPZS_4QIJmQ&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=8&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;

        case 10:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m10.png" alt="">
    
                <div class="card-text">
                  <h3>Mid Doors Molotov</h3>
                  <p>from Lower Tunnels</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=gcQ0xUr6p-w&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=9&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 11:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m11.png" alt="">
    
                <div class="card-text">
                  <h3>Tunnels Molotov</h3>
                  <p>Tunnels Molotov</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=dz40iQ76U9s&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=10&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 12:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m12.png" alt="">
    
                <div class="card-text">
                  <h3>B Big Box Molotov</h3>
                  <p>from B Boxes</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=lPe5pvlUOqE&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=11&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;

        case 13:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m13.png" alt="">
    
                <div class="card-text">
                  <h3>Double Stack B Molotov</h3>
                  <p>from Scaffolding</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=m6u1ZBlrMsg&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=12&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 14:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m14.png" alt="">
    
                <div class="card-text">
                  <h3>Back Plat Molotov</h3>
                  <p>from Outside B Doors</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=q_UmKavutXA&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=13&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;

        case 15:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m15.png" alt="">
    
                <div class="card-text">
                  <h3>Under B Window Molotov</h3>
                  <p>from Scaffolding</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=D8nH9_OWx3I&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=14&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 16:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust molot/m16.png" alt="">
    
                <div class="card-text">
                  <h3></h3>
                  <p></p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=App2rxo57qE&list=PLWdS7h_tsqN79rP3qaZ72hkdLf24-mxPE&index=15&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
      }
      break;

    case "f":
      switch (number) {
        case 1:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="Png/Dust 2/Dust S/S1.png" alt="">
    
                <div class="card-text">
                  <h3>B Site Flash</h3>
                  <p>from B Tunnels</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=y_5ATkCpv2k&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=1&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 2:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S2.png" alt="">
    
                <div class="card-text">
                  <h3>Fence FlasFence Flash</h3>
                  <p>from B Tunnels</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=3S5_aG-OfYU&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=2&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 3:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S3.png" alt="">
    
                <div class="card-text">
                  <h3>B Site Flash</h3>
                  <p>from Tunnels</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=4z7x4-qxNa4&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=3&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 4:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S4.png" alt="">
    
                <div class="card-text">
                  <h3>B Site Flash</h3>
                  <p>from Mid Doors</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=F06mfjVb1kQ&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=4&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 5:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S5.png" alt="">
    
                <div class="card-text">
                  <h3>Mid Doors Flash</h3>
                  <p>from XBox</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=jCXzMq_Ti8k&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=5&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 6:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S6.png" alt="">
    
                <div class="card-text">
                  <h3>Mid Flash</h3>
                  <p>from CT Mid Corner</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=HM64Mm48wt0&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=6&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;

        case 7:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S7.png" alt="">
    
                <div class="card-text">
                  <h3>Short Flash</h3>
                  <p>from Lower Tunnels</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=a2YBsIyRLHA&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=7&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;

        case 8:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S8.png" alt="">
    
                <div class="card-text">
                  <h3>Long doors Flash</h3>
                  <p>from outside bedroom</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=c-MJYXreBLU&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=11&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 9:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                  <img src="/Png/Dust 2/Dust S/S9.png" alt="">
      
                  <div class="card-text">
                    <h3>Long Flash</h3>
                    <p>from Outside long</p>
                    <a target="_blank"
                    href="https://www.youtube.com/watch?v=cqYr-M40xX0&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=12&ab_channel=BeaverUA"
                    class="popup-link"> <button>Дивитися туторіал</button></a>
                  </div>
                </div>`
          );
          content.append(newElement);
          break;
        case 10:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                    <img src="/Png/Dust 2/Dust S/S10.png" alt="">
        
                    <div class="card-text">
                      <h3>Pit Flash</h3>
                      <p>from Long Doors</p>
                      <a target="_blank"
                      href="https://www.youtube.com/watch?v=0Kbwj2BUIIg&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=14&ab_channel=BeaverUA"
                      class="popup-link"> <button>Дивитися туторіал</button></a>
                    </div>
                  </div>`
          );
          content.append(newElement);
          break;
        case 11:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S11.png" alt="">
    
                <div class="card-text">
                  <h3>Long Doors Flash</h3>
                  <p>from Long Corner</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=NL9xpxL6ylc&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=15&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 12:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S12.png" alt="">
    
                <div class="card-text">
                  <h3>A Site Flash</h3>
                  <p>from CT Spawn</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=0RHxnwDC7cU&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=19&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 13:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                  <img src="/Png/Dust 2/Dust S/S13.png" alt="">
      
                  <div class="card-text">
                    <h3>A Long Flash</h3>
                    <p>from CT</p>
                    <a target="_blank"
                    href="https://www.youtube.com/watch?v=mny6MAEGeTI&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=20&ab_channel=BeaverUA"
                    class="popup-link"> <button>Дивитися туторіал</button></a>
                  </div>
                </div>`
          );
          content.append(newElement);
          break;
        case 14:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                    <img src="/Png/Dust 2/Dust S/S14.png" alt="">
        
                    <div class="card-text">
                      <h3>A Ramp Flash</h3>
                      <p>from Short A</p>
                      <a target="_blank"
                      href="https://www.youtube.com/watch?v=-9YtOhDFsak&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=21&ab_channel=BeaverUA"
                      class="popup-link"> <button>Дивитися туторіал</button></a>
                    </div>
                  </div>`
          );
          content.append(newElement);
          break;

        case 15:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Dust 2/Dust S/S15.png" alt="">
    
                <div class="card-text">
                  <h3>A Site Flash</h3>
                  <p>from Short</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=98Nck0sQ_RI&list=PLWdS7h_tsqN46COIwgg1JoindM_wi9orV&index=22&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
      }
      break;
  }

  return divPopup;
}
