const express = require("express");
const mongoose = require("mongoose");
const Image = require("./models/image");
const path = require("path");
const app = express();

app.set("view engine", "ejs");

const db =
  "mongodb+srv://k0dm:qwerty12345@cluster0.muergwi.mongodb.net/node-img?retryWrites=true&w=majority";

mongoose
  .connect(db)
  .then((res) => console.log("Connected to db"))
  .catch((error) => console.log(error));

const port = 3000;
const createPath = (page) => path.resolve(`${page}.ejs`);

app.listen(port, (error) => {
  error ? console.log(error) : console.log(`listening port ${port}`);
});

app.get("index", (req, res) => {
  Image
    .find()
    .then((image)=> res.render(createPath('index'),{index}))

  res.render(createPath(index));
});




