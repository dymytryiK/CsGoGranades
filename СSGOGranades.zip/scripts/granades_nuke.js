function fillContent(divPopup, id) {
  const content = divPopup.querySelector(".card-block");
  console.log("ID =" + id);

  let number = parseInt(id.slice(id.indexOf("-") + 1));

  let newElement = document.createElement("a");

  switch (id[0]) {
    case "s":
      switch (number) {
        case 1:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
            <img src="/Png/Nuke/Nuke SM/S1.png" alt="">

            <div class="card-text">
              <h3>Secret One-Way Smoke</h3>
              <p>from Secret</p>
              <a target="_blank"
              href="https://www.youtube.com/watch?v=iJeYOJFuM6Q&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=1&ab_channel=BeaverUA"
              class="popup-link"> <button>Дивитися туторіал</button></a>
            </div>
          </div>`
          );
          content.append(newElement);
          newElement = document.createElement("a");

          break;
        case 2:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
            <img src="/Png/Nuke/Nuke SM/S2.png" alt="">

            <div class="card-text">
              <h3> Outside Smoke</h3>
              <p> from Under Silo</p>
              <a target="_blank"
              href="https://www.youtube.com/watch?v=K7HerZ-f4_A&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=2&ab_channel=BeaverUA"
              class="popup-link"> <button>Дивитися туторіал</button></a>
            </div>
          </div>`
          );
          content.append(newElement);
          break;
        case 3:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S3.png" alt="">
  
              <div class="card-text">
                <h3>T Red Right Smoke</h3>
                <p>from T Start</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=JmHQPhdMEIA&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=3&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 4:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke SM/S4.png" alt="">
    
                <div class="card-text">
                  <h3>T Red Left Smoke</h3>
                  <p>from T Start/Outside</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=zb5ZzkeInuE&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=4&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 5:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                  <img src="/Png/Nuke/Nuke SM/S5.png" alt="">
      
                  <div class="card-text">
                    <h3>T Red Smoke</h3>
                    <p>from Main</p>
                    <a target="_blank"
                    href="https://www.youtube.com/watch?v=bZsZTwjxD0U&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=5&ab_channel"
                    class="popup-link"> <button>Дивитися туторіал</button></a>
                  </div>
                </div>`
          );
          content.append(newElement);
          break;
        case 6:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
            <img src="/Png/Nuke/Nuke SM/S6.png" alt="">
            
            <div class="card-text">
            <h3>Garage Smoke</h3>
            <p>from T Spawn</p>
            <a target="_blank"
            href="https://www.youtube.com/watch?v=shxKKRJEi5o&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=6&ab_channel=BeaverUA"
            class="popup-link"> <button>Дивитися туторіал</button></a>
            </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 7:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                          <img src="/Png/Nuke/Nuke SM/S7.png" alt="">
              
                          <div class="card-text">
                            <h3>CT Red Smoke</h3>
                            <p>Smoke from T Spawn</p>
                            <a target="_blank"
                            href="https://www.youtube.com/watch?v=fUt3Gndy1Q4&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=7&ab_channel=BeaverUA"
                            class="popup-link"> <button>Дивитися туторіал</button></a>
                          </div>
                        </div>`
          );
          content.append(newElement);
          break;
        case 8:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                      <img src="/Png/Nuke/Nuke SM/S8.png" alt="">
          
                      <div class="card-text">
                        <h3>A Main Smoke</h3>
                        <p>from T Spawn</p>
                        <a target="_blank"
                        href="https://www.youtube.com/watch?v=n97C8xhdALs&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=8&ab_channel=BeaverUA"
                        class="popup-link"> <button>Дивитися туторіал</button></a>
                      </div>
                    </div>`
          );
          content.append(newElement);
          break;
        case 9:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                        <img src="/Png/Nuke/Nuke SM/S9.png" alt="">
            
                        <div class="card-text">
                          <h3>Main Smoke</h3>
                          <p>from T Roof</p>
                          <a target="_blank"
                          href="https://www.youtube.com/watch?v=QUsvsF3FSBw&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=10&ab_channel=BeaverUA"
                          class="popup-link"> <button>Дивитися туторіал</button></a>
                        </div>
                      </div>`
          );
          content.append(newElement);
          break;
        case 10:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                          <img src="/Png/Nuke/Nuke SM/S10.png" alt="">
              
                          <div class="card-text">
                            <h3>Silo Smoke</h3>
                            <p>from CT Spawn</p>
                            <a target="_blank"
                            href=""
                            class="popup-link"> <button>Дивитися туторіал</button></a>
                          </div>
                        </div>`
          );
          content.append(newElement);
          break;
        case 11:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                            <img src="/Png/Nuke/Nuket SM/S11.png" alt="">
                
                            <div class="card-text">
                              <h3>Vent Smoke</h3>
                              <p>from T Spawn</p>
                              <a target="_blank"
                              href="https://www.youtube.com/watch?v=QUsvsF3FSBw&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=10&ab_channel=BeaverUA"
                              class="popup-link"> <button>Дивитися туторіал</button></a>
                            </div>
                          </div>`
          );
          content.append(newElement);
          break;
        case 12:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S12.png" alt="">
  
              <div class="card-text">
                <h3>Next to hut Smoke</h3>
                <p>from Squeaky</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=AKjKw1bur90&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=11&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 13:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke SM/S13.png" alt="">
    
                <div class="card-text">
                  <h3>Next to CT vent Smoke</h3>
                  <p>from Squeaky</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=EXtw4KCclFE&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=12&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 14:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S14.png" alt="">
  
              <div class="card-text">
                <h3>CT Red Smoke</h3>
                <p>from Under Silo</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=mCLTzfe2EXk&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=13&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 15:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S15.png" alt="">
  
              <div class="card-text">
                <h3>Top Blue Smoke</h3>
                <p>from Silo</p>
                <a target="_blank"
                href=""
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 16:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S16.png" alt="">
  
              <div class="card-text">
                <h3>Lockers Window Smoke</h3>
                <p>from T Spawn</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=l4Hl-3myhss&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=14&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 17:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S17.png" alt="">
  
              <div class="card-text">
                <h3>Bombsite A Marshmallow Smoke</h3>
                <p>from Roof</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=dNd_gsNKoXo&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=15&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;

        case 18:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S18.png" alt="">
  
              <div class="card-text">
                <h3>Heaven Outside Smoke</h3>
                <p>from Silo</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=RRaE4axvH_E&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=16&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 19:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S19.png" alt="">
  
              <div class="card-text">
                <h3>Heaven Smoke</h3>
                <p>from Silo</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=WYFKmvtIgRo&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=17&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 20:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
              <img src="/Png/Nuke/Nuke SM/S20.png" alt="">
  
              <div class="card-text">
                <h3>Ramp Smoke</h3>
                <p>from Trophy</p>
                <a target="_blank"
                href="https://www.youtube.com/watch?v=KvQonI6iqBQ&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=18&ab_channel=BeaverUA"
                class="popup-link"> <button>Дивитися туторіал</button></a>
              </div>
            </div>`
          );
          content.append(newElement);
          break;
        case 21:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke SM/S21.png" alt="">
    
                <div class="card-text">
                  <h3>B Site Smoke</h3>
                  <p>from Ramp</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=Pk8wJmwU3os&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=19&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 22:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke SM/S22.png" alt="">
    
                <div class="card-text">
                  <h3>B Site Smoke</h3>
                  <p>from Ramp</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=RcwCYyDvJlc&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=20&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 23:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke SM/S23.png" alt="">
    
                <div class="card-text">
                <h3>Control Smoke</h3>
                <p>from Ramp</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=StgsiRrbCuk&list=PLWdS7h_tsqN7BonodmRBnVbF_gWSPciOS&index=21&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
      }
      break;
    case "m":
      switch (number) {
        case 1:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m1.png" alt="">
    
                <div class="card-text">
                <h3>Dark Molotov</h3>
                <p>from B Ramp</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=bR2LbpYUbGo&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=7&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 2:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m2.png" alt="">
    
                <div class="card-text">
                <h3>Rafters Molotov</h3>
                <p>from T Roof</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=XgJam3Wva9I&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=2&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 3:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m3.png" alt="">
    
                <div class="card-text">
                <h3>A Site Molotov</h3>
                <p>from Heaven</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=4LFlQAH4woE&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=5&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 4:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m4.png" alt="">
    
                <div class="card-text">
                <h3>Hut Roof Molotov</h3>
                <p>from T Roof</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=hAeMRrFrMi4&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=9&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 5:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m5.png" alt="">
    
                <div class="card-text">
                <h3>Squeaky Molotov</h3>
                <p>from Heaven</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=4heNMSyChPU&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=1&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 6:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m6.png" alt="">
    
                <div class="card-text">
                <h3>Silo Molotov</h3>
                <p>from Outside</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=sAIttaOupNw&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=8&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;

        case 7:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m7.png" alt="">
    
                <div class="card-text">
                <h3>Left Vent Molotov</h3>
                <p>from Outside Hut Door</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=odqxx7ZVVyw&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=3&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 8:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m8.png" alt="">
    
                <div class="card-text">
                <h3>Red Molotov</h3>
                <p>from Under Silo</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=vWb8_ml7vZo&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=6&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 9:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke molot/m9.png" alt="">
    
                <div class="card-text">
                <h3>Secret Molotov</h3>
                <p>from Yard</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=nsxz0-iWtf8&list=PLWdS7h_tsqN7hAH4O0sKLyDKRHTWAyXTS&index=4&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
      }

      break;
    case "f":
      switch (number) {
        case 1:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="
                Png/Nuke/Nuke S/s1.png" alt="">
    
                <div class="card-text">
                <h3>Vent Flash</h3>
                <p>from Tetris</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=TtswOnXq7Yc&list=PLWdS7h_tsqN59hYatX_R-LMgibzDQwlts&index=1&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 2:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke S/s2.png" alt="">
    
                <div class="card-text">
                <h3>Ramp Area Flash</h3>
                <p>from Trophy</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=gsob20hFa_o&list=PLWdS7h_tsqN59hYatX_R-LMgibzDQwlts&index=2&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 3:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke S/s3.png" alt="">
    
                <div class="card-text">
                <h3>A Site Flash</h3>
                <p>from Roof</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=0vC35cDPIoA&list=PLWdS7h_tsqN59hYatX_R-LMgibzDQwlts&index=5&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 4:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke S/s4.png" alt="">
    
                <div class="card-text">
                <h3>Bombsite A Flash</h3>
                <p>from Roof</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=y0UaxJjRDBw&list=PLWdS7h_tsqN59hYatX_R-LMgibzDQwlts&index=7&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 5:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke S/s5.png" alt="">
    
                <div class="card-text">
                <h3>Outside Hut Flash</h3>
                <p>from Lobby</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=Sml2U5eAcmQ&list=PLWdS7h_tsqN59hYatX_R-LMgibzDQwlts&index=8&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
        case 6:
          newElement.insertAdjacentHTML(
            "beforeend",
            `<div class="card-content">
                <img src="/Png/Nuke/Nuke S/s6.png" alt="">
    
                <div class="card-text">
                <h3>A Main Flash</h3>
                <p>from Silo</p>
                  <a target="_blank"
                  href="https://www.youtube.com/watch?v=_S2swzebbiI&list=PLWdS7h_tsqN59hYatX_R-LMgibzDQwlts&index=11&ab_channel=BeaverUA"
                  class="popup-link"> <button>Дивитися туторіал</button></a>
                </div>
              </div>`
          );
          content.append(newElement);
          break;
      }
      break;
  }

  return divPopup;
}
